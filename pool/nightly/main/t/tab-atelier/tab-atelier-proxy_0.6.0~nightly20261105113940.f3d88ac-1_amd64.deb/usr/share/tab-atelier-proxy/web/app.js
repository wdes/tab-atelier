"use strict";
// SPDX-License-Identifier: MPL-2.0
//
// Account management UI. Vue 3 global build, no bundler: the proxy serves the
// compiled output and the vendored libraries as they are.
//
// SOURCE. The file the proxy serves is ../assets/app.js, compiled from here —
// edit this one. `bun run build` in crates/tab-atelier-proxy/web, and the
// `web_assets` test fails if the committed output is stale.
const { createApp } = Vue;
// The HTTP client, from api.ts. Read off the namespace rather than left as a
// top-level `api` const over there: both files are scripts sharing one scope,
// so a name declared in one is visible — and can collide — in the other.
const { api } = window.TaApi;
/** The tool policy every request already gets, and the one an account that
 *  predates the field is carrying. `all` sends the client's toolkit through
 *  untouched — the only default that cannot silently break a session. */
function defaultTools() {
    return { mode: "all", disable: [], allow: [], add: [], rewrite: {} };
}
/** Commas or newlines — a pasted column of names is as likely as a typed list,
 *  and neither separator can appear inside a tool name. */
function splitNames(text) {
    return text
        .split(/[,\n]/)
        .map((s) => s.trim())
        .filter(Boolean);
}
/**
 * One rewrite rule per line: a tool name, then `dates`, `provider`, or a
 * `find -> replace` pair.
 *
 * Throws on a line it cannot read rather than dropping it. A rule silently
 * discarded here is a policy that silently does not do what it says, and the
 * typist has no way to notice — the failure mode is an extra sentence three
 * turns later, which is not a thing anyone traces back to this box.
 * `saveTools` shows the message the way it shows a `JSON.parse` failure.
 */
function splitRules(text) {
    const rules = {};
    for (const raw of text.split("\n")) {
        const line = raw.trim();
        if (!line || line.startsWith("#"))
            continue;
        const cut = line.search(/\s/);
        if (cut < 0)
            throw new Error(`"${line}" names a tool but gives no rule for it`);
        const name = line.slice(0, cut);
        const rest = line.slice(cut).trim();
        let rule;
        if (rest === "dates" || rest === "provider") {
            rule = rest;
        }
        else {
            const arrow = rest.indexOf("->");
            if (arrow < 0) {
                throw new Error(`"${line}" is not dates, provider, or a find -> replace pair`);
            }
            const find = rest.slice(0, arrow).trim();
            if (!find)
                throw new Error(`"${line}" has nothing to find`);
            // An empty replacement is allowed: deleting a sentence is a rewrite.
            rule = { replaced: { find, replace: rest.slice(arrow + 2).trim() } };
        }
        if (!rules[name])
            rules[name] = [];
        rules[name].push(rule);
    }
    return rules;
}
/** The inverse of `splitRules`, for filling the editor. */
function formatRules(rules) {
    const lines = [];
    for (const [name, list] of Object.entries(rules)) {
        for (const rule of list) {
            lines.push(rule === "dates" || rule === "provider"
                ? `${name} ${rule}`
                : `${name} ${rule.replaced.find} -> ${rule.replaced.replace}`);
        }
    }
    return lines.join("\n");
}
/** A provider's current models, in the `id:class:cost` form the server parses.
 *
 * Sent on every save because the form edits one field at a time and the server
 * replaces what it is given: a save that omitted the models would wipe them.
 * Deprecated ones are dropped — they are listed for reference and must not be
 * re-sent as current. */
function providerModels(p) {
    return p.models
        .filter((m) => !m.deprecated)
        .map((m) => `${m.id}:${m.class}:${m.relative_cost}`)
        .join(",");
}
/** A zeroed usage record, for an account that has not called anything yet. */
function emptyWindow() {
    return {
        calls: 0,
        errors: 0,
        tokens: { input: 0, output: 0, cache_read: 0, cache_write: 0, total: 0 },
        // Nothing is known about this account's hop, so nothing is claimed about
        // its price. `null` keeps the "unpriced" state distinct from a real $0.00.
        cost: null,
    };
}
function emptyUsage(id) {
    return {
        user: {
            id,
            first_name: "",
            last_name: "",
            email: "",
            created_at: 0,
            disabled: false,
            weight: 1,
            keys: [],
            last_used_at: null,
            has_key: false,
            provider: null,
            // No pin: the caller's own model is honoured, as before.
            model: null,
            // Off, matching the server's default and the `#[serde(default)]` that
            // gives every account already on disk the same value.
            compact: "none",
            tools: defaultTools(),
        },
        last_24h: emptyWindow(),
        last_7d: emptyWindow(),
        all_time: emptyWindow(),
        series_hourly: [],
        // Empty rather than a guessed range: this is only ever read for an account
        // the server has not reported on yet, and a made-up span would draw an
        // axis with the wrong dates on it. The caller that draws charts fetches
        // the real window off the response.
        window: { start: "", end: "", hours: 0 },
        // No rate known yet, so the money unit stays unavailable rather than
        // letting an unpriced account be plotted at zero.
        cost_model: null,
    };
}
/**
 * A button that turns into a spinner and a gerund while its work runs.
 *
 * The page had six of these and they had drifted apart by one `me-1` — the
 * spinner sitting on the word instead of beside it. Each spelled the same
 * four parts by hand: the `spinner-border` span, the `role="status"`, the
 * label swap, and the disable. `label` is the idle word, `busyLabel` its
 * gerund.
 *
 * No `disabled` prop: every caller already disabled the button on the exact
 * flag it spun on, so deriving it here is what keeps the two from drifting
 * again. A `class` passed from the call site still lands on the <button>,
 * which is how each keeps its own margin.
 *
 * Declared here rather than read off a namespace like the charts: this is
 * app chrome, not a chart, and charts.js is wrapped in an IIFE so its names
 * never reach this scope to collide with.
 */
/** A blank row, so the editor opens with somewhere to type. */
function blankRoute() {
    return {
        from: "",
        kind: "",
        from_provider: "",
        tool: "",
        to_model: "",
        to_provider: "",
        saved: null,
    };
}
/** A stored route as a draft row. */
function draftFrom(r) {
    return {
        from: r.from ?? "",
        kind: r.kind ?? "",
        from_provider: r.from_provider ?? "",
        tool: r.tool ?? "",
        to_model: r.to_model,
        to_provider: r.to_provider ?? "",
        saved: r,
    };
}
const BusyButton = Vue.defineComponent({
    name: "BusyButton",
    props: {
        busy: Boolean,
        label: { type: String, required: true },
        busyLabel: { type: String, required: true },
    },
    emits: ["click"],
    template: `
    <button class="btn btn-sm btn-outline-secondary" :disabled="busy" @click="$emit('click')">
      <span v-if="busy" class="spinner-border spinner-border-sm me-1" role="status" aria-hidden="true"></span>{{ busy ? busyLabel : label }}
    </button>
  `,
});
// Bound to a const before `createApp` sees it. Passing the literal inline
// leaves Vue unable to tie `data`, `computed` and `methods` together, and it
// fails open: `this` becomes `any` in methods and `{}` in computed, so the
// file type-checks while checking nothing.
const AdminApp = Vue.defineComponent({
    // Read off the namespace rather than destructured into consts: these files
    // are plain <script> tags sharing one scope, so a top-level `const
    // CallsChart` here collides with the one in charts.js and the page dies with
    // a redeclaration SyntaxError before Vue ever mounts.
    components: {
        BusyButton,
        CallsChart: window.TaCharts.CallsChart,
        TokensChart: window.TaCharts.TokensChart,
        PressureChart: window.TaCharts.PressureChart,
    },
    data() {
        return {
            // sessionStorage, not localStorage: the operator token should not outlive
            // the tab it was typed into. And not a cookie: a cookie would be attached
            // to every request the origin makes, including the vendored scripts, and
            // the token has no business travelling on those.
            token: sessionStorage.getItem("ta-proxy-admin") || "",
            authed: false,
            users: [],
            form: { first_name: "", last_name: "", email: "" },
            freshKey: null,
            copied: false,
            error: "",
            busy: false,
            usageBusy: false,
            pressureBusy: false,
            // Per-panel, for the same reason as the chart flags: a fetch that greys
            // out unrelated controls reads as the page being broken.
            providersBusy: false,
            bodyView: "structure",
            /**
             * The key dialog, when open.
             *
             * Holds the masked credential the server reported plus the replacement
             * being typed, so the dialog can show "which key is installed" and "set a
             * new one" in the same place — which is how the provider frontends this
             * imitates do it, and it is the only way to tell a rotation worked.
             */
            keyFor: null,
            inspectBusy: false,
            origin: window.location.origin,
            // Per-account usage, keyed by id, as returned by /api/usage.
            usage: {},
            // 24 h, not the week: the question this page gets opened for is "what is
            // happening now" — a spike, a burst of errors, a key that just started
            // being used. A 7-day default flattens exactly that into the noise floor,
            // and the wider windows are one click away.
            //
            // A token, not an hour count: "this week" is the current calendar week,
            // whose length depends on when you ask. `Window::token` on the server
            // canonicalises it, and `loadUsage` writes back whatever comes home, so
            // this stays one of a known set.
            usageWindow: "24h",
            // null = everyone; an account id = just them. Clicking a row's token
            // total drills in, which is the only question the summed charts cannot
            // answer ("who is that spike?").
            focus: null,
            // What the token charts count. "tokens" is the provider's own number;
            // every other unit is an estimate (see TaCharts.SOURCE_ENERGY), and the
            // UI says so wherever one is shown.
            unit: "tokens",
            // The shared plan, as Anthropic reports it. Real data even when the
            // per-person numbers are seeded — this one is not ours to invent.
            pressure: null,
            pressureTimer: null,
            // Inspection: null until the panel is opened, so nothing is fetched —
            // and nothing hints that captures exist — unless someone asks.
            inspect: null,
            inspectOpen: null,
            providers: null,
            tools: null,
            // The route editor. Opened from the row, saved per row rather than whole:
            // each route is validated on its own — an unknown destination or provider
            // is refused for that rule — so there is no combination state to protect,
            // unlike the tools editor.
            routes: null,
            // "Weight" is the scheduler's word for this and means nothing to anyone
            // reading a table of people. The stored value is still a weight — the
            // API and the QoS maths are unchanged — but the UI names what it does.
            //
            // Normal sits in the MIDDLE so a CI account or a backlog fleet can yield
            // without everyone else needing a promotion. Roughly geometric, so each
            // step is a real difference: Background gets a tenth of what Normal
            // does, Critical ten times.
            tiers: [
                { weight: 1, label: "Background" },
                { weight: 2, label: "Low" },
                { weight: 5, label: "Normal" },
                { weight: 10, label: "Elevated" },
                { weight: 20, label: "High" },
                { weight: 50, label: "Critical" },
            ],
        };
    },
    computed: {
        /**
         * The open capture's body as tree rows, parsed once.
         *
         * A computed rather than a call in the template: the template asks for it
         * three times per render — for the toggle's disabled state, for the row count
         * and for the list — and `jsonRows` parses the whole body on each call. A
         * multi-megabyte capture would re-parse it several times per keystroke.
         *
         * Cached on the body string, so it re-parses exactly when the selection
         * changes and not when anything else on the page does.
         */
        inspectRows() {
            const body = this.inspectOpen ? this.inspectOpen.request_body : "";
            return body ? this.jsonRows(body) : null;
        },
        plan() {
            return this.pressure?.plan || {};
        },
        sched() {
            return this.pressure?.scheduler || {};
        },
        degradeAbove() {
            return this.pressure?.degrade_above ?? 0.85;
        },
        planUtil() {
            return this.plan.utilization ?? null;
        },
        // Whether to draw the plan panel at all. Deliberately the API's own answer
        // rather than a check for a missing credential here: the proxy has already
        // decided whether it is spending the plan, and the two must not be able to
        // disagree — a graph drawn for a subscription the router is not using
        // reports on nothing. Requires the fetch to have landed, so the panel does
        // not flash on before the first response says otherwise.
        planAvailable() {
            return this.pressure !== null && this.plan.available === true;
        },
        planHealth() {
            return this.plan.health || {};
        },
        // Whether the MONITOR is broken, as opposed to the plan being busy. The
        // two used to be indistinguishable on this page: a failing poll produced
        // a sample with no numbers, planSeries dropped it, and the chart simply
        // ended — which reads as "nothing happened since noon" rather than "we
        // stopped being able to look".
        monitorBroken() {
            return this.planHealth.stale === true || (this.planHealth.consecutive_failures ?? 0) > 0;
        },
        // What to say about it, in words, without making anyone read a log.
        monitorProblem() {
            if (!this.monitorBroken)
                return "";
            const h = this.planHealth;
            const since = h.last_ok_ts ? `last good reading ${this.whenLocal(h.last_ok_ts)}` : "no good reading yet";
            const n = h.consecutive_failures ?? 0;
            const failures = n === 1 ? "1 failed poll" : `${n} failed polls`;
            return `${since} · ${failures}`;
        },
        // Spelled out beside the number, so the state never rests on colour.
        planState() {
            // Checked before the utilisation branches: an unknown plan must not be
            // described as a healthy one, and this is the state routing is in too.
            if (this.planHealth.stale)
                return "plan unknown — the reading is too old to act on";
            if (this.sched.backoff_for)
                return "upstream is rate-limiting — everything is waiting";
            if (this.planUtil == null)
                return "no reading yet";
            if (this.planUtil >= (this.pressure?.floor_above ?? 0.95))
                return "nearly exhausted — falling back to the cheapest model";
            if (this.planUtil >= this.degradeAbove)
                return "tight — large models are being downgraded";
            return "healthy — nothing is being throttled";
        },
        planClass() {
            if (this.planHealth.stale)
                return "text-body-secondary";
            if (this.sched.backoff_for || (this.planUtil ?? 0) >= (this.pressure?.floor_above ?? 0.95))
                return "text-danger";
            if ((this.planUtil ?? 0) >= this.degradeAbove)
                return "text-warning";
            return "";
        },
        weeklyUtil() {
            return this.plan.latest?.seven_day ?? null;
        },
        // The weekly cap can be the binding one even while the session window
        // looks calm, so it gets the same warning treatment rather than staying
        // grey until someone happens to read the number.
        weeklyClass() {
            const w = this.weeklyUtil;
            if (w == null)
                return "";
            if (w >= 0.95)
                return "text-danger";
            if (w >= this.degradeAbove)
                return "text-warning";
            return "";
        },
        planSeries() {
            return (this.plan.history || [])
                .filter((s) => s.five_hour != null || s.seven_day != null)
                .map((s) => ({
                // `?? null` rather than passing the optional through: a missing
                // reading and an absent field are the same thing to the chart, and
                // `undefined` would slip past a `!= null` guard as a hole.
                util: s.five_hour ?? s.seven_day ?? null,
                seven_day: s.seven_day ?? null,
                label: this.whenLocal(s.ts),
            }));
        },
        scopeLabel() {
            if (!this.focus)
                return "everyone";
            const u = this.users.find((x) => x.id === this.focus);
            return u ? `${u.first_name} ${u.last_name}` : "unknown";
        },
        tokenUnits() {
            return window.TaCharts.UNIT_OPTIONS;
        },
        unitName() {
            // The header names the chart's unit, so it must agree with the axis and
            // with the tiles below it: derive it from the same tallest bucket rather
            // than echoing the select's base label (`Wh` beside numbers in `kWh`).
            //
            // `chartTop` converts before returning, the contract `unitSuffix` names
            // from and `unitStep` labels ticks with. Under money that matters twice
            // over: the drawn value is not a rescaling of a token count, so passing
            // the raw field would name the axis from a number in a different unit
            // entirely (an hour of `deepseek-flash` is ~150k tokens and ~$0.03).
            return window.TaCharts.unitSuffix(window.TaCharts.chartTop(this.series, this.unit), this.unit);
        },
        unitNote() {
            if (this.unit === "tokens")
                return "";
            if (this.unit === "usd") {
                // The caveat is part of the figure, not a footnote to it: without it a
                // total that quietly omits an unpriced account reads as a total.
                const missing = this.unpricedAccounts;
                return missing === 0
                    ? window.TaCharts.moneyNote()
                    : `${window.TaCharts.moneyNote()} ${missing} account(s) in this view have no price and are not included.`;
            }
            return window.TaCharts.energyNote();
        },
        /** How many accounts in the current view are unpriced, out of the ones shown. */
        unpricedAccounts() {
            const all = Object.values(this.usage);
            const chosen = this.focus ? all.filter((u) => u.user.id === this.focus) : all;
            return chosen.filter((u) => !u.cost_model).length;
        },
        // The series the charts draw: one account's, or every account's summed
        // hour by hour. Summing here rather than server-side keeps /api/usage a
        // plain per-account dump that the drill-down can reuse without refetching.
        series() {
            const all = Object.values(this.usage);
            const chosen = this.focus ? all.filter((u) => u.user.id === this.focus) : all;
            if (!chosen.length)
                return [];
            const first = chosen[0];
            if (!first)
                return [];
            const base = first.series_hourly.map((b) => ({ ...b }));
            // Money sums only when something in the view is actually priced. Left
            // null when nothing is, so an unpriced selection draws an empty panel
            // rather than a confident line along zero — the same distinction the
            // server keeps, and the one a `?? 0` here would throw away.
            const priced = chosen.some((u) => u.cost_model);
            for (const acct of chosen.slice(1)) {
                acct.series_hourly.forEach((b, i) => {
                    const t = base[i];
                    if (!t || t.hour !== b.hour)
                        return;
                    t.calls += b.calls;
                    t.errors += b.errors;
                    t.input += b.input;
                    t.output += b.output;
                    t.cache_read += b.cache_read;
                    t.cache_write += b.cache_write;
                    if (priced) {
                        t.cost_in_micro = (t.cost_in_micro ?? 0) + (b.cost_in_micro ?? 0);
                        t.cost_out_micro = (t.cost_out_micro ?? 0) + (b.cost_out_micro ?? 0);
                        // The third charge. Left out of this sum, every added account would
                        // quietly drop its search and fetch costs from the merged view.
                        if (b.cost_tools_micro != null) {
                            t.cost_tools_micro = (t.cost_tools_micro ?? 0) + b.cost_tools_micro;
                        }
                    }
                });
            }
            return base;
        },
        /**
         * One calls line per account, for the un-focused view.
         *
         * Slots come from the ACCOUNT LIST POSITION, not from size. Two reasons,
         * and the second is the one that matters:
         *
         *  - colour must follow the entity, never its rank, or an hour where
         *    somebody else is busiest repaints the whole chart;
         *  - clicking a row sets `focus`, and a size-ordered palette would
         *    recolour every remaining account at that moment. Stable slots mean
         *    the line you were following stays the same colour when you drill in.
         *
         * Past eight, the rest fold into a muted "Other" — a ninth hue is never
         * generated, because a generated one is not colourblind-safe and the
         * ordering is what makes the palette work at all.
         */
        callsByUser() {
            // Focused: the chart draws the single summed series instead, and an
            // empty list is how it is told to.
            if (this.focus)
                return [];
            const withUsage = this.users.filter((u) => this.usage[u.id]);
            if (withUsage.length < 2)
                return [];
            const grid = this.series.map((b) => b.hour);
            const series = withUsage.map((u, i) => {
                const acct = this.usage[u.id];
                const byHour = new Map((acct?.series_hourly ?? []).map((b) => [b.hour, b]));
                // Rebuilt on the SAME grid as `series`, so index alignment with the
                // x axis is guaranteed rather than assumed — the chart maps a series
                // point to an x position by index.
                const points = grid.map((hour) => {
                    const b = byHour.get(hour);
                    return {
                        hour,
                        calls: b?.calls ?? 0,
                        errors: b?.errors ?? 0,
                        input: b?.input ?? 0,
                        output: b?.output ?? 0,
                        cache_read: b?.cache_read ?? 0,
                        cache_write: b?.cache_write ?? 0,
                    };
                });
                return { id: u.id, name: u.first_name || u.email, slot: 0, points };
            });
            const calls = (s) => s.points.reduce((a, p) => a + p.calls, 0);
            const drawn = series.filter((s) => s.points.some((p) => p.calls > 0));
            if (drawn.length <= 8) {
                // Slots come from the position in THIS list — the account list, which
                // the server returns in a fixed order — so they are stable across
                // refreshes and across a focus change.
                return drawn.map((s, i) => ({ ...s, slot: i }));
            }
            // Past eight, the busiest eight keep a colour and the rest are summed.
            const busiest = new Set([...drawn]
                .sort((a, b) => calls(b) - calls(a))
                .slice(0, 8)
                .map((s) => s.id));
            // …but the kept eight take their slots from the STABLE order, not from
            // their rank by size. Numbering them by rank would repaint every line the
            // moment one account overtook another, and — as this was first written —
            // could hand out slot 8, 9 or 10 to the busiest accounts, which the
            // eight-slot palette maps to muted ink and so renders indistinguishably
            // from the folded group.
            const kept = drawn.filter((s) => busiest.has(s.id));
            const other = series.filter((s) => !busiest.has(s.id));
            const folded = {
                id: "__other__",
                name: `Other (${other.length})`,
                slot: -1,
                points: grid.map((hour, i) => ({
                    hour,
                    calls: other.reduce((a, s) => a + (s.points[i]?.calls ?? 0), 0),
                    errors: other.reduce((a, s) => a + (s.points[i]?.errors ?? 0), 0),
                    input: 0,
                    output: 0,
                    cache_read: 0,
                    cache_write: 0,
                })),
            };
            return [...kept.map((s, i) => ({ ...s, slot: i })), folded];
        },
        tiles() {
            const sum = (pick) => this.series.reduce((a, b) => a + pick(b), 0);
            const calls = sum((b) => b.calls);
            const errors = sum((b) => b.errors);
            const input = sum((b) => b.input);
            const output = sum((b) => b.output);
            const cache = sum((b) => b.cache_read);
            // Any priced hour is enough to make the total meaningful; a view with
            // none reports the dash instead of a confident `$0.00`.
            const priced = this.series.some((b) => b.cost_in_micro != null);
            // All three components, because this figure is compared against the invoice.
            // Tokens are the bulk of it; the server-tool charges are billed per request and
            // no token rate reproduces them, so leaving them out would understate the total
            // by exactly the search and fetch traffic.
            const paid = sum((b) => (b.cost_in_micro ?? 0) + (b.cost_out_micro ?? 0) + (b.cost_tools_micro ?? 0));
            const toolCharge = sum((b) => b.cost_tools_micro ?? 0);
            return [
                { label: "API calls", value: this.fmt(calls), sub: errors ? `${errors} failed` : "none failed" },
                { label: "Tokens", value: this.fmt(input + output + cache), sub: "input + output + cache" },
                { label: "Input", value: this.fmt(input), sub: cache ? `${this.fmt(cache)} from cache` : "no cache hits" },
                { label: "Output", value: this.fmt(output), sub: this.scopeLabel },
                {
                    label: "Cost",
                    value: priced ? window.TaCharts.fmtMoney(paid) : "—",
                    sub: !priced
                        ? "no price known for this hop"
                        : toolCharge
                            ? "at list rates · incl. search/fetch"
                            : "at list rates · see the token chart note",
                },
                {
                    label: "Energy",
                    value: window.TaCharts.withUnit(window.TaCharts.convertTokens(input + output + cache, "wh"), "wh"),
                    // Deliberately not a bare number: the conversion is a published
                    // estimate over an assumed prompt size, and the chart carries the
                    // citation. A tile that reads as measured would be a lie.
                    sub: "estimated · see the token chart note",
                },
            ];
        },
        meUrl() {
            return `${this.origin}/me/usage`;
        },
        // Both recipes carry the real key. It is readable exactly once, so a
        // `<key>` placeholder here means hand-copying 68 characters out of the
        // field above — and the commonest way that goes wrong is a truncated
        // paste, which fails as "no active account has that key" and reads like a
        // proxy fault rather than a typo.
        relayRecipe() {
            const key = this.freshKey ? this.freshKey.key : "<key>";
            // `--label` is a named flag. This block used to say `remote add proxy
            // --url …`, which the CLI rejects outright as an unknown argument.
            return [
                `tab-atelier remote add --label proxy --url ${this.origin} --relay-token ${key}`,
                "tab-atelier relay via proxy",
                "tab-atelier relay on",
            ].join("\n");
        },
        // The proxy's Anthropic path lives under /relay/anthropic; the client
        // appends /v1/messages itself.
        envRecipe() {
            const key = this.freshKey ? this.freshKey.key : "<key>";
            return [
                `export ANTHROPIC_BASE_URL=${this.origin}/relay/anthropic`,
                `export ANTHROPIC_API_KEY=${key}`,
            ].join("\n");
        },
        // Every model this proxy could route a person to, one entry per CHOICE
        // rather than per model.
        //
        // On the Anthropic wire a model takes tools and reasoning at once, so it
        // gets a single entry. On the OpenAI wire it cannot — a request carrying
        // tools has to force reasoning off — so the same model is offered twice:
        // once with tools (which is how an agent works), once with reasoning and
        // no tools at all. The value encodes both, because the two halves travel
        // by different routes: the model half pins the account, the flavour half
        // is the account's tool policy.
        modelChoices() {
            const all = this.providers ? this.providers.providers : [];
            const seen = new Set();
            const out = [];
            for (const p of all) {
                if (!p.enabled)
                    continue;
                for (const m of p.models) {
                    if (m.deprecated || seen.has(m.id))
                        continue;
                    seen.add(m.id);
                    out.push({ value: m.id, label: m.id });
                }
            }
            return out.sort((a, b) => a.label.localeCompare(b.label));
        },
        mappingModelChoices() {
            return this.modelChoices.map((choice) => choice.value);
        },
    },
    mounted() {
        // A token already in this session means a reload should land straight back
        // on the list rather than asking for it again.
        if (this.token) {
            api.token = this.token;
            void this.load();
        }
    },
    methods: {
        /**
         * A model's published rates, or nothing where none are recorded.
         *
         * A method rather than a computed, because it takes the thing it labels.
         * `computed` entries are getters that Vue evaluates with no arguments, so
         * the template's `priceLabel(m)` would call the getter's *result* — which
         * threw `priceLabel is not a function` and left the whole page blank,
         * because Vue aborts the render on the first such error. Helpers that take
         * an argument belong here.
         *
         * Trims to three significant places rather than two decimals: the rates run
         * from $0.003 to $15 per 1M, so `toFixed(2)` would render the cache-hit
         * rate — the one figure the whole cache story turns on — as `$0.00`.
         */
        priceLabel(m) {
            if (!m.price)
                return "";
            const rate = (micro) => {
                const usd = micro / 1_000_000;
                const text = usd >= 1 ? usd.toFixed(2) : usd.toFixed(4).replace(/0+$/, "").replace(/\.$/, "");
                return `$${text}`;
            };
            const p = m.price;
            return `${rate(p.cache_hit)} / ${rate(p.input)} / ${rate(p.output)} per 1M`;
        },
        // Load everything the page shows, and treat success as proof the token is
        // good — there is no separate check to make, and a second round trip could
        // only disagree with this one.
        async load() {
            this.busy = true;
            this.error = "";
            try {
                this.users = await api.users.list();
                await this.loadUsage();
                await this.loadPressure();
                // With the rest, not behind a button: the account table's "routed to"
                // dropdown reads this list, so leaving it unloaded gave every row an
                // empty picker and made a configured proxy look like it had no
                // providers at all.
                await this.loadProviders();
                this.authed = true;
                sessionStorage.setItem("ta-proxy-admin", this.token);
                // The plan moves on its own, independently of anything done here.
                this.pressureTimer ??= setInterval(() => this.loadPressure(), 30_000);
            }
            catch (e) {
                this.error = e instanceof Error ? e.message : String(e);
                // A rejected token is cleared, so the operator is asked again rather
                // than left tapping at a page that will keep refusing. Anything else —
                // a network fault, a 500 — keeps it: the credential may be perfectly
                // good and the proxy briefly unwell.
                this.authed = false;
            }
            finally {
                this.busy = false;
            }
        },
        /** Sign in with the operator token, then load everything the page shows. */
        async signIn() {
            // Trimmed: a token pasted from a terminal usually brings a newline, and
            // the comparison on the server is exact.
            this.token = (this.token || "").trim();
            api.token = this.token;
            await this.load();
        },
        /** Forget the token, in the client and in this session. */
        signOut() {
            sessionStorage.removeItem("ta-proxy-admin");
            this.token = "";
            api.token = "";
            this.authed = false;
            this.users = [];
            this.usage = {};
            this.focus = null;
            this.pressure = null;
            this.inspect = null;
            this.inspectOpen = null;
            this.freshKey = null;
            // Guarded: `clearInterval(null)` is legal JavaScript and a type error,
            // and the guard costs nothing.
            if (this.pressureTimer !== null)
                clearInterval(this.pressureTimer);
            this.pressureTimer = null;
        },
        async refresh() {
            this.users = await api.users.list();
            await this.loadUsage();
            // Kept in step with the account list: a provider added or removed in
            // another tab would otherwise leave every row's picker showing stale
            // choices.
            if (this.providers)
                await this.loadProviders();
        },
        // Inspection. Nothing is fetched until the panel is opened: a page that
        // silently pulled captured prompts on every load would be collecting them
        // into a browser as well as a file.
        /**
         * Fetch the provider list, with the panel's spinner on.
         *
         * The busy flag lives in here rather than in the button's handler on
         * purpose: `refresh`, `setCompact`, `addPreset` and the rest all reload
         * this list, and a spinner that only appears for one of them would look
         * like the page had hung for the others.
         */
        async loadProviders() {
            this.providersBusy = true;
            try {
                this.providers = await api.providers.list();
            }
            finally {
                this.providersBusy = false;
            }
        },
        async addPreset(p) {
            // Ask for a name first. The generated one (`deepseek-2`) is fine for a
            // throwaway second key but useless once there are three entries that differ
            // by which account or key they carry — which is exactly when someone reaches
            // for a name. Cancelling the prompt aborts, so this doubles as the way to
            // change your mind; leaving it empty accepts the generated name.
            const name = prompt(`Name for this ${p.label} entry (blank for "${p.id}", "${p.id}-2", …):`, "");
            if (name === null)
                return;
            // `dup` makes this an ADDED entry, not an edit of one already there:
            // clicking DeepSeek twice has to leave two rows with two key files, not
            // one row holding whichever key was pasted last.
            this.providersBusy = true;
            try {
                await api.providers.save({ preset: p.id, dup: true, id: name.trim() });
                await this.loadProviders();
            }
            catch (e) {
                // A refused name (a path separator, a collision) is the operator's to
                // correct, and the server says why — surface it rather than swallowing it
                // in a busy flag.
                this.error = e instanceof Error ? e.message : String(e);
            }
            finally {
                this.providersBusy = false;
            }
        },
        /**
         * Open the key dialog for one provider.
         *
         * Fetches the masked credential first, so the dialog can say which key is
         * installed — `sk-0cb68*****31ff` — rather than asking the operator to
         * replace a key they cannot identify. If the fetch fails the dialog still
         * opens with the reason, because being unable to *see* the key is not a
         * reason to be unable to set one.
         */
        async openKey(p) {
            this.keyFor = { provider: p, info: null, input: "", busy: true, saved: false };
            try {
                const info = await api.providers.key(p.id);
                if (this.keyFor && this.keyFor.provider.id === p.id)
                    this.keyFor.info = info;
            }
            catch (e) {
                this.error = e instanceof Error ? e.message : String(e);
            }
            finally {
                if (this.keyFor)
                    this.keyFor.busy = false;
            }
        },
        /** Replace the key shown in the dialog, then re-read it to confirm. */
        async saveKey() {
            const dialog = this.keyFor;
            if (!dialog)
                return;
            const value = dialog.input.trim();
            if (value === "")
                return;
            dialog.busy = true;
            try {
                await api.providers.rotateKey(dialog.provider.id, value);
                // Re-read rather than assume: the masked value the dialog shows next is
                // the server's, so a key that did not take is visible as the old
                // fingerprint instead of a success message over nothing.
                const info = await api.providers.key(dialog.provider.id);
                if (this.keyFor) {
                    this.keyFor.info = info;
                    this.keyFor.input = "";
                    this.keyFor.saved = true;
                }
                this.error = "";
                await this.loadProviders();
            }
            catch (e) {
                this.error = e instanceof Error ? e.message : String(e);
            }
            finally {
                if (this.keyFor)
                    this.keyFor.busy = false;
            }
        },
        /**
         * Rename a provider.
         *
         * A server operation, not a field edit: the id names the key file and is the
         * string accounts pin to and rules reference, so it has to move all of them
         * together. Renaming to the same name is allowed and does nothing, which is
         * what makes the prompt safe to confirm without reading it twice.
         */
        async renameProvider(p) {
            const to = prompt(`New name for ${p.id}:`, p.id);
            if (to === null)
                return;
            const trimmed = to.trim();
            if (trimmed === "" || trimmed === p.id)
                return;
            this.providersBusy = true;
            try {
                await api.providers.rename(p.id, trimmed);
                this.error = "";
                await this.loadProviders();
            }
            catch (e) {
                // A refused name (taken, or not usable as a filename) is the operator's
                // to correct and the server says why.
                this.error = e instanceof Error ? e.message : String(e);
            }
            finally {
                this.providersBusy = false;
            }
        },
        async toggleProvider(p) {
            await api.providers.save({
                id: p.id,
                base_url: p.base_url,
                models: p.models.filter((m) => !m.deprecated).map((m) => `${m.id}:${m.class}:${m.relative_cost}`).join(","),
                preference: p.preference,
            });
            await this.loadProviders();
        },
        // Changing how much of an old conversation this provider is sent.
        //
        // Refused client-side with the SERVER's own explanation — `compact_refusal`
        // is the same rule the save path enforces, sent up rather than restated
        // here, because a second copy of "which provider is the subscription"
        // would eventually disagree with the first.
        //
        // Deliberately not via `act`: that clears `this.error` before running, so
        // the reason would be wiped by the very call it explains. The select is
        // bound with `:value`, not `v-model`, so a refused change snaps back to
        // what is actually stored.
        async setCompact(p, value) {
            if (value !== "none" && p.compact_refusal) {
                this.error = p.compact_refusal;
                return;
            }
            this.busy = true;
            try {
                await api.providers.save({
                    id: p.id,
                    base_url: p.base_url,
                    models: p.models.filter((m) => !m.deprecated).map((m) => `${m.id}:${m.class}:${m.relative_cost}`).join(","),
                    compact: value,
                });
                this.error = "";
                await this.loadProviders();
            }
            catch (e) {
                this.error = e instanceof Error ? e.message : String(e);
            }
            finally {
                this.busy = false;
            }
        },
        // ── model routes ─────────────────────────────────────────────────────
        //
        // Routes are "when this account's traffic matches these conditions, serve
        // that instead". Opened from a row, saved one rule at a time: each rule is
        // validated on its own by the server, so unlike the tools editor there is no
        // combination to protect and no reason to hold a whole set hostage to one bad
        // row.
        /**
         * Models to offer for one account's model pin.
         *
         * Filtered by the provider it is pinned to, because a provider pin is a
         * containment boundary: offering another provider's models builds a
         * combination whose meaning the operator did not intend. An exception to the
         * boundary is a Model mapping rule, which is a deliberate, visible thing.
         *
         * With no pin the full catalogue is right — the account may be routed
         * anywhere.
         *
         * A model that the pin does NOT serve is still included when it is the one
         * currently stored: hiding it would blank the select and lose the only
         * evidence that this account carries a combination the boundary does not
         * allow. It is marked so the operator can see why it is there.
         */
        modelsForProvider(providerId, current) {
            const all = this.providers ? this.providers.providers : [];
            if (!providerId)
                return this.modelChoices;
            const p = all.find((x) => x.id === providerId);
            if (!p)
                return this.modelChoices;
            const seen = new Set();
            const out = [];
            for (const m of p.models) {
                if (m.deprecated || seen.has(m.id))
                    continue;
                seen.add(m.id);
                out.push({ value: m.id, label: m.id });
            }
            if (current && !seen.has(current) && current !== "") {
                out.unshift({ value: current, label: `${current} — not served by ${p.id}` });
            }
            return out.sort((a, b) => a.label.localeCompare(b.label));
        },
        /**
         * Sources offered for one rule's "when they ask for".
         *
         * The catalogue, plus the rule's own `from` when it is not in it. A rule may
         * name an id the catalogue has dropped — that is how traffic for a retired
         * model gets caught — and dropping it from the list would silently reset the
         * field to "any model" the next time the rule was opened and saved. It is
         * shown marked rather than omitted, so the operator can see what it is and
         * replace it deliberately.
         */
        routeFromChoices(r) {
            const all = [...this.mappingModelChoices];
            if (r.from && !all.includes(r.from))
                all.unshift(r.from);
            return all;
        },
        /**
         * Destinations offered for one rule, narrowed by its "from" provider.
         *
         * The same rule as the model pin: naming a provider is a boundary, so a
         * destination it does not serve is not offered. When "anywhere" is chosen
         * the whole catalogue is right, since the destination decides the hop.
         *
         * The rule's current destination is kept even when it falls outside the
         * narrowed list — a rule stored before this restriction, or one whose
         * provider no longer serves that model, must stay visible rather than
         * silently blanking.
         */
        routeToModelChoices(r) {
            const all = this.mappingModelChoices.map((id) => ({ value: id, label: id }));
            if (!r.to_provider) {
                if (r.to_model && !all.some((m) => m.value === r.to_model)) {
                    all.unshift({ value: r.to_model, label: r.to_model });
                }
                return all;
            }
            const p = (this.providers ? this.providers.providers : []).find((x) => x.id === r.to_provider);
            if (!p)
                return all;
            const seen = new Set();
            const out = [];
            for (const m of p.models) {
                if (m.deprecated || seen.has(m.id))
                    continue;
                seen.add(m.id);
                out.push({ value: m.id, label: m.id });
            }
            if (r.to_model && !seen.has(r.to_model)) {
                out.unshift({ value: r.to_model, label: `${r.to_model} — not served by ${p.id}` });
            }
            return out;
        },
        /**
         * Open the editor on this account's rules.
         *
         * No blank row is appended. A pre-filled row reads as "this account already
         * has an empty rule", and one waiting at the bottom of the list invites a save
         * of nothing — so the editor shows what exists and offers a button to add the
         * first one.
         */
        openRoutes(u) {
            this.routes = {
                id: u.id,
                rows: (u.routes ?? []).map(draftFrom),
            };
        },
        addRouteRow() {
            if (this.routes)
                this.routes.rows.push(blankRoute());
        },
        /**
         * Remove one rule — from the server, not just from the list.
         *
         * This used to splice the row out of `rows` and stop there, so the rule
         * stayed in the store: the modal said it was gone, the next load brought it
         * back, and the operator's only evidence was that the thing they deleted
         * kept returning. Removing a row is a write.
         *
         * Two cases, and the difference matters:
         *
         * * A row the operator has just added (`saved === null`) exists only in this
         *   form, so discarding it needs no request — and must not make one, since a
         *   half-filled rule has no conditions the server could match.
         * * A stored row is identified by the conditions it was READ with, not by
         *   whatever the form holds now. The operator may have edited it before
         *   deciding to remove it, and those edits identify a rule that does not
         *   exist; deleting with them would silently do nothing while looking like it
         *   worked.
         */
        async removeRoute(i) {
            if (!this.routes)
                return;
            const row = this.routes.rows[i];
            if (!row)
                return;
            // Never stored, so nothing to undo on the server.
            if (!row.saved) {
                // Just drop it. Replacing it with a fresh blank would make removing the
                // last row look like nothing happened, and puts a row the operator did not
                // ask for back in front of them.
                this.routes.rows.splice(i, 1);
                return;
            }
            const accountId = this.routes.id;
            const saved = row.saved;
            this.busy = true;
            try {
                // An empty destination is the deletion verb: the same convention the
                // model pin uses for clearing. Sent with the stored conditions so it
                // names exactly the rule the operator is looking at.
                const updated = await api.users.setRoute(accountId, {
                    from: saved.from ?? "",
                    kind: saved.kind ?? "",
                    from_provider: saved.from_provider ?? "",
                    tool: saved.tool ?? "",
                    to_model: "",
                    to_provider: null,
                });
                const editor = this.routes;
                if (editor && editor.id === accountId) {
                    editor.rows = (updated.routes ?? []).map(draftFrom);
                }
                this.error = "";
                await this.refresh();
            }
            catch (e) {
                this.error = e instanceof Error ? e.message : String(e);
                // The row is left in place: a failed delete means the rule is still
                // there, and hiding that would be the same lie the local splice told.
                await this.refresh();
            }
            finally {
                this.busy = false;
            }
        },
        /**
         * Save one row.
         *
         * Empty destination removes the rule those conditions identify — the same
         * convention the model pin uses for clearing, so the operator does not have
         * to learn a second verb to undo what they just did.
         */
        async saveRoute(i) {
            if (!this.routes)
                return;
            const row = this.routes.rows[i];
            // `noUncheckedIndexedAccess`: an index into an array is not proof of an
            // element. Saving a row that has been removed under the click is nothing
            // to do, not a crash.
            if (!row)
                return;
            // Captured now, because the editor may be closed before the request
            // returns and `this.routes` would then be null.
            const accountId = this.routes.id;
            const payload = {
                from: row.from.trim(),
                kind: row.kind.trim(),
                from_provider: row.from_provider.trim(),
                tool: row.tool.trim(),
                to_model: row.to_model.trim(),
                to_provider: row.to_provider.trim() || null,
            };
            this.busy = true;
            try {
                const updated = await api.users.setRoute(accountId, payload);
                // Re-read the stored rules rather than trusting the draft: the server
                // canonicalises both ends, so what came back is what a request will
                // actually match against. Skipped if the editor was closed while the
                // request was in flight — the save still happened, the form is just gone.
                const editor = this.routes;
                if (editor && editor.id === accountId) {
                    editor.rows = (updated.routes ?? []).map(draftFrom);
                }
                this.error = "";
                await this.refresh();
            }
            catch (e) {
                this.error = e instanceof Error ? e.message : String(e);
                // The draft is kept on failure: a refused rule is usually one field away
                // from a good one, and clearing the form would make the operator retype
                // it to find out which.
                await this.refresh();
            }
            finally {
                this.busy = false;
            }
        },
        // The account's own compaction level. Bound with `:value`, not `v-model`,
        // like the provider select below was: a refused change must snap back to
        // what is actually stored, and the server is the one that refuses — it
        // knows every hop this account could reach, the browser does not.
        async setUserCompact(u, value) {
            this.busy = true;
            try {
                await api.users.setCompact(u.id, value);
                this.error = "";
                await this.refresh();
            }
            catch (e) {
                this.error = e instanceof Error ? e.message : String(e);
                await this.refresh();
            }
            finally {
                this.busy = false;
            }
        },
        // The model pin, which is really a model-and-flavour pin. See
        // `modelChoices` for why the two halves are encoded in one value; here
        // they are split apart and sent to the two endpoints that own them.
        //
        // The order matters. Turning tools off first, then pinning, leaves no
        // window in which the account is pinned to an OpenAI model while still
        // carrying tools — which is the state that would 400 upstream, since
        // that wire cannot serve tools without forcing reasoning off.
        //
        // The flavour is not a field of its own: it is `tools.mode`, because on
        // this wire whether tools may ride along IS whether reasoning is on. That
        // makes the mode read as the flavour, so choosing "tools" has to clear the
        // `none` that meant "reasoning". Without that the select snaps straight
        // back to the label it was on and the other one is unreachable — a
        // one-way door out of a perfectly ordinary starting state.
        //
        // Back to `all`, not to one of the narrower modes: nothing remembers which
        // of the three tools-carrying modes was in force before reasoning was
        // chosen, and they are not interchangeable. The allow/disable lists
        // survive either way and take effect again as soon as a mode selects them.
        async setUserModel(u, value) {
            this.busy = true;
            try {
                const cut = value.lastIndexOf("#");
                const model = cut === -1 ? value : value.slice(0, cut);
                const flav = cut === -1 ? "" : value.slice(cut + 1);
                const mode = flav === "reasoning" ? "none"
                    : flav === "tools" && u.tools.mode === "none" ? "all"
                        : null;
                if (mode) {
                    await api.users.setTools(u.id, {
                        mode,
                        disable: u.tools.disable,
                        allow: u.tools.allow,
                        add: u.tools.add,
                        rewrite: u.tools.rewrite,
                    });
                }
                await api.users.setModel(u.id, model);
                this.error = "";
                await this.refresh();
            }
            catch (e) {
                this.error = e instanceof Error ? e.message : String(e);
                await this.refresh();
            }
            finally {
                this.busy = false;
            }
        },
        // Does this person's work land on the OpenAI wire? Only then do the two
        // flavours of a model exist to choose between.
        wireOf(u) {
            const p = this.providers?.providers.find((q) => q.id === u.provider);
            return p ? p.wire : "anthropic";
        },
        // What the select should show: the pin, plus which flavour it is in.
        // Nothing stored reads as "" so the browser picks the placeholder.
        userModelValue(u) {
            if (!u.model)
                return "";
            if (this.wireOf(u) !== "openai")
                return u.model;
            return `${u.model}#${u.tools.mode === "none" ? "reasoning" : "tools"}`;
        },
        // The tool editor. Opened from the row and saved whole, because the
        // refusals are about the COMBINATION — a name in both `disable` and
        // `allow`, a definition with no name — and three fields saved one at a
        // time would pass through states the operator never chose.
        editTools(u) {
            this.tools = {
                id: u.id,
                mode: u.tools.mode,
                disable: u.tools.disable.join(", "),
                allow: u.tools.allow.join(", "),
                // Pretty-printed, not compact: someone may open this to read a
                // definition, and a tool schema is not one line long.
                add: u.tools.add.length ? JSON.stringify(u.tools.add, null, 2) : "",
                rewrite: formatRules(u.tools.rewrite),
            };
        },
        saveTools() {
            const t = this.tools;
            if (!t)
                return Promise.resolve();
            // Parsed here rather than sent as a string for the server to parse:
            // a syntax error in a text box is the typist's, and `JSON.parse` can say
            // where it is. What the server gets is the stored shape.
            // `JsonObject[]`, not `unknown[]`: a tool definition is a JSON object —
            // name, description, input schema — so the object form is both the
            // accurate type and the one that keeps `JsonValue`'s recursion out of
            // Vue's inferred `this`, which is where it blew up as TS2589. The one
            // `any` involved is `JSON.parse`'s return type, and it is contained to
            // the assignment below: from there the value is narrowed before use.
            let added = [];
            if (t.add.trim()) {
                let parsed;
                try {
                    parsed = JSON.parse(t.add);
                }
                catch (e) {
                    this.error = `that is not valid JSON: ${e instanceof Error ? e.message : e}`;
                    return Promise.resolve();
                }
                if (!Array.isArray(parsed)) {
                    this.error = "the added tools must be a JSON array of definitions";
                    return Promise.resolve();
                }
                added = parsed;
            }
            let rewrite;
            try {
                rewrite = splitRules(t.rewrite);
            }
            catch (e) {
                this.error = e instanceof Error ? e.message : String(e);
                return Promise.resolve();
            }
            return this.act(async () => {
                await api.users.setTools(t.id, {
                    mode: t.mode,
                    disable: splitNames(t.disable),
                    allow: splitNames(t.allow),
                    add: added,
                    rewrite,
                });
                this.tools = null;
            });
        },
        async removeProvider(p) {
            if (!confirm(`Remove provider ${p.id}? Accounts pinned to it are unpinned.`))
                return;
            await api.providers.remove(p.id);
            await this.loadProviders();
            await this.refresh();
        },
        /**
         * Take a provider out of service, or put it back.
         *
         * Distinct from Remove, and the distinction is the point: this keeps the
         * entry, its key and its models, so the reversal is one click. Remove
         * forgets all of it and unpins whoever was routed there.
         *
         * The checkbox is bound with `:checked` rather than `v-model`, so a
         * refusal snaps it back to what the server actually holds instead of
         * showing a state that was never saved.
         */
        async setProviderEnabled(p, enabled) {
            this.busy = true;
            try {
                await api.providers.save({
                    id: p.id,
                    base_url: p.base_url,
                    models: p.models.filter((m) => !m.deprecated).map((m) => `${m.id}:${m.class}:${m.relative_cost}`).join(","),
                    enabled,
                });
                this.error = "";
            }
            catch (e) {
                this.error = e instanceof Error ? e.message : String(e);
            }
            finally {
                this.busy = false;
                // Either way: on success to reflect what was stored, on failure to put
                // the tick back where it was.
                await this.loadProviders();
            }
        },
        async setUserProvider(u, provider) {
            await api.users.setProvider(u.id, provider);
            await this.refresh();
        },
        /** What the row's badge says: enough to tell "governed" from "default"
         *  without opening the editor, and no more. The mode is the headline; the
         *  counts are there so a policy that only adds tools does not read the
         *  same as one that only removes them. */
        toolsBadge(u) {
            const parts = [];
            if (u.tools.mode !== "all")
                parts.push(u.tools.mode);
            if (u.tools.disable.length)
                parts.push(`−${u.tools.disable.length}`);
            if (u.tools.add.length)
                parts.push(`+${u.tools.add.length}`);
            // A rewrite changes no counts, so without this a policy that only
            // rewrites is indistinguishable from one with no policy at all.
            if (Object.keys(u.tools.rewrite ?? {}).length)
                parts.push("~");
            return parts.join(" ") || "default";
        },
        // The account's compaction level, as words rather than wire spelling.
        compactLabel(u) {
            const found = this.providers?.compact_levels.find((c) => c.value === u.compact);
            return found ? found.label : u.compact;
        },
        // What compaction took off this request before it was sent.
        //
        // Worth showing on every capture, including when it saved nothing: the
        // panel renders the body AS SENT, so without this a compacted request is
        // indistinguishable from one that was simply small — and "is compaction
        // on at all" is the question this answers.
        compactionSummary(c) {
            const k = c.compaction;
            if (!k)
                return "";
            const pct = k.bytes_before ? Math.round((1 - k.bytes_after / k.bytes_before) * 100) : 0;
            return `compacted ${this.fmt(k.bytes_before)} → ${this.fmt(k.bytes_after)} (−${pct}%)`;
        },
        // "12 tool results, 4 thinking, 2 notices" — what the level actually did,
        // which is not the same as what it is set to.
        compactionDetail(c) {
            const k = c.compaction;
            if (!k)
                return "";
            const parts = [];
            if (k.tool_results_elided)
                parts.push(`${k.tool_results_elided} tool results`);
            if (k.tool_results_kept_for_error)
                parts.push(`${k.tool_results_kept_for_error} errors kept`);
            if (k.tool_results_kept_small)
                parts.push(`${k.tool_results_kept_small} too small to save`);
            if (k.thinking_dropped)
                parts.push(`${k.thinking_dropped} thinking`);
            if (k.notices_dropped)
                parts.push(`${k.notices_dropped} notices`);
            return parts.length ? `${k.level}: ${parts.join(", ")}` : `${k.level}: nothing to remove`;
        },
        // The provider's schedule is written in UTC; the person reading it is not.
        // "peak pricing now" without an end is a warning nobody can plan around,
        // so show when it lifts — on their own clock, with the zone named. The
        // zone label is what makes the time unambiguous rather than local-looking.
        peakUntil(p) {
            if (!p.peak_until)
                return "";
            const end = new Date(p.peak_until * 1000);
            const now = new Date();
            const sameDay = end.getFullYear() === now.getFullYear() &&
                end.getMonth() === now.getMonth() &&
                end.getDate() === now.getDate();
            const time = end.toLocaleTimeString(undefined, {
                hour: "2-digit",
                minute: "2-digit",
                timeZoneName: "short",
                ...(sameDay ? {} : { weekday: "short" }),
            });
            return ` until ${time}`;
        },
        // Everything the provider reported for the request, not a summary of it:
        // the cache split says whether a charge was a write or a read, the tier
        // says which queue served it, and the server-tool counter says whether the
        // call fetched anything. Those are the numbers that explain a surprising
        // bill, and the API already sent them.
        tokenSummary(c) {
            const t = c.tokens;
            if (!t)
                return "—";
            const parts = [`in ${this.fmt(t.input)}`, `out ${this.fmt(t.output)}`];
            if (t.cache_read)
                parts.push(`cache read ${this.fmt(t.cache_read)}`);
            if (t.cache_write) {
                let w = `cache write ${this.fmt(t.cache_write)}`;
                if (t.cache_write_5m || t.cache_write_1h) {
                    const split = [
                        `5m ${this.fmt(t.cache_write_5m ?? 0)}`,
                        `1h ${this.fmt(t.cache_write_1h ?? 0)}`,
                    ];
                    w += ` (${split.join(" · ")})`;
                }
                parts.push(w);
            }
            // Named, not bare: "priority" alone reads as a queue position, which is
            // the wrong idea — it is the rate the call was billed at.
            if (t.service_tier)
                parts.push(`tier ${t.service_tier}`);
            if (t.web_search)
                parts.push(`web search ×${this.fmt(t.web_search)}`);
            if (t.web_fetch)
                parts.push(`web fetch ×${this.fmt(t.web_fetch)}`);
            return parts.join(" · ");
        },
        async loadInspect() {
            this.inspectBusy = true;
            try {
                this.inspect = await api.inspect.get();
            }
            finally {
                this.inspectBusy = false;
            }
        },
        async armInspect() {
            const raw = prompt(`Capture the JSON sent to Anthropic for how many minutes? (max ${this.inspect?.max_arm_minutes ?? 60})\n\n` +
                "Captures contain PROMPTS — whatever people are working on. Credentials are stripped, " +
                "the rest is not. Recording stops by itself when the time is up.", "15");
            if (!raw)
                return;
            const minutes = Number(raw);
            if (!Number.isFinite(minutes) || minutes < 1)
                return;
            await api.inspect.arm(minutes);
            await this.loadInspect();
        },
        // One action, because "stop recording" and "delete what you recorded" are
        // the same intention in practice.
        async stopInspect() {
            if (!confirm("Stop capturing and delete every capture taken so far?"))
                return;
            await api.inspect.disarm();
            this.inspectOpen = null;
            await this.loadInspect();
        },
        prettyJson(body) {
            try {
                return JSON.stringify(JSON.parse(body), null, 2);
            }
            catch {
                // Truncated captures are deliberately not valid JSON — say so rather
                // than showing an error the operator has to decode.
                return body;
            }
        },
        /**
         * A body as coloured runs, for a template `v-for`.
         *
         * Runs rather than an HTML string: the body is written by whoever holds a
         * key, so it is rendered through Vue's interpolation, which escapes it.
         * `v-html` would execute a `"<img onerror=…>"` sitting in a system prompt.
         */
        jsonTokens(body) {
            const pretty = this.prettyJson(body);
            // A run per token is a `<span>` per token, and a body near the capture
            // cap has millions. Past this size plain text is the only rendering that
            // will not lock up the tab, and JSON this large is not read by eye.
            if (pretty.length > 262144)
                return [{ cls: "", text: pretty }];
            const re = /"(?:\\.|[^"\\])*"|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?|\b(?:true|false|null)\b/g;
            const out = [];
            let last = 0;
            for (const m of pretty.matchAll(re)) {
                const text = m[0];
                const at = m.index;
                if (text === undefined || at === undefined)
                    continue;
                if (at > last)
                    out.push({ cls: "", text: pretty.slice(last, at) });
                // A string is a key when a colon follows it: its value is what the
                // reader is looking for and the key is only the label on the drawer.
                const cls = text.startsWith('"')
                    ? /^[ \t\r\n]*:/.test(pretty.slice(at + text.length)) ? "ta-j-key" : "ta-j-str"
                    : /^(?:true|false|null)$/.test(text) ? "ta-j-lit" : "ta-j-num";
                out.push({ cls, text });
                last = at + text.length;
            }
            if (last < pretty.length)
                out.push({ cls: "", text: pretty.slice(last) });
            return out;
        },
        /**
         * The request body as readable rows, for the Structure view.
         *
         * Flattened into a list with a depth per row rather than nested markup: a
         * recursive component per level is a lot of machinery for what amounts to an
         * outline, and a flat list keeps the whole body in one scroll container so the
         * browser does not have to lay out thousands of nested boxes.
         *
         * Two limits, both for the same reason — a capture can be megabytes and JSON
         * that large is not read by eye:
         *   - `depth` stops at 8, and anything below says so rather than vanishing;
         *   - strings are cut to 160 characters, with the full value in the row's
         *     `title` so hovering shows the rest.
         *
         * Returns `null` when the body is not JSON: the caller then shows the raw
         * text alone, because a parse failure is worth seeing rather than hiding
         * behind an empty tree.
         */
        jsonRows(body) {
            let parsed;
            try {
                parsed = JSON.parse(body);
            }
            catch {
                return null;
            }
            const out = [];
            const walk = (value, key, depth) => {
                const pad = depth;
                if (depth > 8) {
                    out.push({ pad, key, kind: "more", text: "… deeper than this view shows" });
                    return;
                }
                if (value === null) {
                    out.push({ pad, key, kind: "null", text: "null" });
                }
                else if (typeof value === "string") {
                    const oneLine = value.length > 160 ? `${value.slice(0, 160)}…` : value;
                    // A newline inside a string would break the row into several lines and
                    // destroy the alignment the tree depends on. Shown as the literal `\n`
                    // rather than a symbol, because that is how the value reads in the raw
                    // view next door — and because it keeps this file pure ASCII, which the
                    // commit gate enforces on every added line.
                    out.push({ pad, key, kind: "str", text: oneLine.replace(/\n/g, "\\n"), title: value });
                }
                else if (typeof value === "number" || typeof value === "boolean") {
                    out.push({ pad, key, kind: "num", text: String(value) });
                }
                else if (Array.isArray(value)) {
                    out.push({ pad, key, kind: "open", text: `[ ${value.length} ]` });
                    value.forEach((v, i) => walk(v, String(i), pad + 1));
                }
                else if (typeof value === "object") {
                    const n = Object.keys(value).length;
                    out.push({ pad, key, kind: "open", text: `{ ${n} ${n === 1 ? "field" : "fields"} }` });
                    for (const [k, v] of Object.entries(value)) {
                        walk(v, k, pad + 1);
                    }
                }
            };
            // The top level is an object in practice; walking it directly keeps the
            // first row from being a pointless `{ 12 fields }` above its own contents.
            if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
                for (const [k, v] of Object.entries(parsed))
                    walk(v, k, 0);
            }
            else {
                walk(parsed, "", 0);
            }
            return out;
        },
        /**
         * The first eight characters of an opaque id, for display.
         *
         * A session id and a device id are both long enough to wrap the line they
         * sit on and short enough in their distinctive part that eight characters
         * tell two apart. Enough to compare two rows against each other, which is
         * the only thing this column is for — the full value is in the JSON below,
         * where anyone who needs it can read it.
         */
        shortHash(value) {
            if (!value)
                return "—";
            return value.length <= 8 ? value : value.slice(0, 8);
        },
        /**
         * What to call the server-side tool a capture ran, for a badge.
         *
         * The family name is shown verbatim — `web_search`, not `web search`. It is
         * the identifier an operator greps for, and the proxy has already dropped
         * the version date so the label survives Anthropic's next revision.
         */
        serverToolLabel(c) {
            return c.server_tool ?? "";
        },
        // Quiet by default because of the 30 s poll: a failing read must not blank
        // the accounts page it sits on, and a banner raised on every tick would be
        // unreadable. A reload someone pressed is not quiet — silence there is
        // indistinguishable from a button that does nothing.
        async loadPressure(quiet = true) {
            try {
                this.pressure = await api.pressure.get();
            }
            catch (e) {
                if (!quiet)
                    this.error = e instanceof Error ? e.message : String(e);
            }
        },
        async reloadPressure() {
            this.pressureBusy = true;
            this.error = "";
            try {
                await this.loadPressure(false);
            }
            finally {
                this.pressureBusy = false;
            }
        },
        // A weight set through the API need not be on the ladder, so the select
        // has to be able to show it rather than silently snapping it to a tier.
        tierLabel(weight) {
            const t = this.tiers.find((x) => x.weight === weight);
            return t ? t.label : `Custom (${weight})`;
        },
        tiersFor(u) {
            const w = u.weight || 1;
            return this.tiers.some((t) => t.weight === w)
                ? this.tiers
                : [...this.tiers, { weight: w, label: this.tierLabel(w) }].sort((a, b) => a.weight - b.weight);
        },
        // What this priority actually works out to, if everyone were busy at once.
        // A number like "3" is meaningless on its own; "≈60% when everyone is
        // busy" is the decision being made.
        shareOf(u) {
            const active = this.users.filter((x) => !x.disabled);
            const total = active.reduce((a, x) => a + (x.weight || 1), 0);
            if (u.disabled)
                return "disabled";
            if (!total || active.length < 2)
                return "all of it when alone";
            return `≈${Math.round(((u.weight || 1) / total) * 100)}% when all busy`;
        },
        // The value arrives from a `<select>`'s `$event.target.value`, which is a
        // string whatever the option's `:value` was bound to — so `string` is what
        // this actually receives, and the coercion below is not redundant.
        setWeight(u, value) {
            const weight = Math.max(1, Math.min(100, Number(value) || 1));
            return this.act(() => api.users.setWeight(u.id, weight));
        },
        async loadUsage() {
            const data = await api.usage.report(this.usageWindow);
            // The server owns the window vocabulary and echoes the canonical token
            // back — `48h` settles to `2d`, and a window it did not recognise falls
            // back to its default. Taking that value rather than keeping the one we
            // sent is what stops the dropdown and the graph disagreeing.
            this.usageWindow = data.window;
            const next = {};
            for (const u of data.users)
                next[u.user.id] = u;
            this.usage = next;
            // Drilling into someone who has since been deleted would show an empty
            // chart with their name on it.
            if (this.focus && !next[this.focus])
                this.focus = null;
        },
        // The loader throws where its callers already catch (saving a weight, the
        // window picker's own handler); a reload pressed by hand has no such caller.
        async reloadUsage() {
            this.usageBusy = true;
            this.error = "";
            try {
                await this.loadUsage();
            }
            catch (e) {
                this.error = e instanceof Error ? e.message : String(e);
            }
            finally {
                this.usageBusy = false;
            }
        },
        // Rows render before the first usage load returns, and for an account
        // that has never called anything there is simply no entry.
        usageOf(id) {
            // The placeholder is a COMPLETE AccountUsage. It used to carry only
            // `last_7d` and `all_time`, which was fine while the table read nothing
            // else — and would have become `undefined.calls` the moment anything
            // touched `last_24h` or `series_hourly` on an account with no usage yet.
            // The type is what turned that from a future bug into a compile error.
            return this.usage[id] ?? emptyUsage(id);
        },
        // Mean tokens per call. `—` rather than 0 when nobody called: dividing by
        // no calls is not an average of zero, and showing one invites the reading
        // that this account is cheap when it is simply idle.
        avgPerCall(id) {
            const u = this.usageOf(id).last_7d;
            if (!u.calls)
                return "— avg/call";
            return `${this.fmt(Math.round(u.tokens.total / u.calls))} avg/call`;
        },
        fmt(n) {
            if (n >= 1e9)
                return `${(n / 1e9).toFixed(1)}B`;
            if (n >= 1e6)
                return `${(n / 1e6).toFixed(1)}M`;
            if (n >= 1e3)
                return `${(n / 1e3).toFixed(1)}k`;
            return String(n ?? 0);
        },
        // Every mutation funnels through here so a failure always lands in the
        // banner instead of the console, and the list can never drift from the
        // server's state after a partial success.
        // Generic, so the caller's own return type is what is checked: the result
        // is discarded here, but naming it `unknown` would have meant every call
        // site converting its real type to `unknown` first, which is where the
        // `any` creeps back in.
        async act(fn) {
            this.busy = true;
            this.error = "";
            try {
                await fn();
                await this.refresh();
            }
            catch (e) {
                this.error = e instanceof Error ? e.message : String(e);
            }
            finally {
                this.busy = false;
            }
        },
        // Creating someone mints no key. A key is named for the machine it lives
        // on — that is what makes losing a laptop one row to delete instead of a
        // re-key of everything that person runs — and a key handed out at signup
        // is the one that gets deployed with no name at all. So ask where this
        // first one goes, in the same breath.
        add() {
            return this.act(async () => {
                const who = await api.users.add(this.form);
                this.form = { first_name: "", last_name: "", email: "" };
                const name = prompt(`Account created. Where will ${who.first_name}'s first key be used? (laptop, ci, fleet…)`, "laptop");
                if (!name)
                    return;
                const k = await api.keys.add(who.id, name);
                this.showKey({ user: who, key: k.secret, name: k.key.name });
            });
        },
        // Adding a key never disturbs the existing ones, which is what makes
        // moving a machine across safe: add, deploy, then delete the old one.
        addKey(u) {
            const name = prompt(`Name for ${u.first_name}'s new key (laptop, ci, fleet…)`, "");
            if (!name)
                return;
            return this.act(async () => {
                const data = await api.keys.add(u.id, name);
                this.showKey({ user: u, key: data.secret, name: data.key.name });
            });
        },
        // A key's tabs, newest first. Sorted here rather than at render so the
        // per-key list and the merged per-person list below cannot disagree about
        // what "most recent" means.
        keySessions(k) {
            return (k.sessions ?? []).slice().sort((a, b) => b.last_seen_at - a.last_seen_at);
        },
        // Every tab this person has, across all their keys, deduplicated by
        // session id.
        //
        // The same session id can appear under two keys — a machine re-keyed
        // mid-session, or one credential replaced by another while a tab stayed
        // open — and showing it twice would read as two tabs. The *newest* sighting
        // wins, because that is the key the tab is using now; the earlier key still
        // lists it separately, which is deliberate, since that is where the record
        // of *that credential* belongs.
        userSessions(u) {
            const bySession = new Map();
            for (const k of u.keys ?? []) {
                for (const s of this.keySessions(k)) {
                    const seen = bySession.get(s.session_id);
                    if (seen === undefined || s.last_seen_at > seen.last_seen_at)
                        bySession.set(s.session_id, s);
                }
            }
            return [...bySession.values()].sort((a, b) => b.last_seen_at - a.last_seen_at);
        },
        // `5b91b78b · 323056b1 · 2m ago`, with the full values in the tooltip: a
        // session uuid and a 64-hex device fingerprint are far too long for a table
        // cell, but both are needed in full to match against a Claude Code log.
        sessionLabel(s) {
            const parts = [this.shortHash(s.session_id), this.shortHash(s.device_id ?? undefined)];
            return `${parts.join(" · ")} · ${this.ago(s.last_seen_at)}`;
        },
        sessionTitle(s) {
            return [
                `session  ${s.session_id}`,
                `device   ${s.device_id ?? "unknown"}`,
                s.account_uuid ? `account  ${s.account_uuid}` : "",
                `first seen ${new Date(s.first_seen_at * 1000).toLocaleString()}`,
                `last seen  ${new Date(s.last_seen_at * 1000).toLocaleString()}`,
            ]
                .filter(Boolean)
                .join("\n");
        },
        removeKey(u, k) {
            if (!confirm(`Delete ${u.first_name}'s key "${k.name}"? Anything using it stops working. Their other keys are unaffected.`))
                return;
            return this.act(() => api.keys.remove(u.id, k.id));
        },
        toggleKey(u, k) {
            return this.act(() => api.keys.setDisabled(u.id, k.id, !k.disabled));
        },
        setDisabled(u, disabled) {
            return this.act(() => api.users.setDisabled(u.id, disabled));
        },
        remove(u) {
            if (!confirm(`Delete ${u.first_name} ${u.last_name} <${u.email}>? Their key stops working.`))
                return;
            return this.act(() => api.users.remove(u.id));
        },
        showKey(data) {
            this.copied = false;
            this.freshKey = {
                who: `${data.user.first_name} ${data.user.last_name} <${data.user.email}>`,
                key: data.key,
                name: data.name ? `"${data.name}"` : "",
            };
        },
        async copy(text) {
            try {
                await navigator.clipboard.writeText(text);
                this.copied = true;
            }
            catch {
                // Clipboard access needs a secure context; over plain http on a LAN
                // address it simply is not there. The field is selectable, so say what
                // to do instead of failing silently.
                this.error = "Clipboard unavailable (needs HTTPS) — select the key and copy it manually.";
            }
        },
        // Every timestamp the proxy emits carries a zone — epoch seconds, or ISO
        // 8601 with an offset. Rendering is the browser's job, in the zone of
        // whoever is looking: chopping the offset off the string and showing the
        // rest, which is what this used to do, silently displays UTC as if it were
        // local. An hour wrong is worse than no timestamp.
        whenLocal(iso) {
            if (iso === null || iso === undefined)
                return "";
            const d = new Date(iso);
            if (Number.isNaN(d.getTime()))
                return String(iso);
            return d.toLocaleString([], { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" });
        },
        // "resets 09:00" is only useful if you already know what time it is there.
        // What anybody actually wants is how long they have.
        untilLocal(iso) {
            if (iso === null || iso === undefined)
                return "";
            const d = new Date(iso);
            if (Number.isNaN(d.getTime()))
                return "";
            const mins = Math.round((d.getTime() - Date.now()) / 60000);
            if (mins <= 0)
                return "any moment";
            if (mins < 60)
                return `in ${mins} min`;
            const h = Math.floor(mins / 60);
            const m = mins % 60;
            return m ? `in ${h} h ${m} min` : `in ${h} h`;
        },
        ago(secs) {
            if (!secs)
                return "never";
            const d = Math.floor(Date.now() / 1000) - secs;
            if (d < 90)
                return "just now";
            if (d < 5400)
                return `${Math.floor(d / 60)} min ago`;
            if (d < 172800)
                return `${Math.floor(d / 3600)} h ago`;
            return `${Math.floor(d / 86400)} d ago`;
        },
    },
});
const app = createApp(AdminApp);
// A render error is not fatal, but Vue treats it as one: it aborts the render,
// leaving `#app` as whatever the template had produced so far — nothing, for a
// first paint. So a mistake anywhere in the template shows as a blank white
// page with the cause only in a console nobody has open, which is how
// `priceLabel is not a function` reached production.
//
// Two things happen instead. The error is reported to the console with the
// component that raised it, so it is diagnosable from a screenshot of the
// console rather than a live debugger. And the page is replaced with something
// that says so, because a visible failure is strictly better than a blank one:
// a blank page is indistinguishable from "the proxy is down", "the network is
// broken" and "you typed the wrong port", and it invites reloading rather than
// reporting.
//
// Deliberately not a retry or a recovery: whatever was rendered is gone, and
// guessing at a partial re-render would hide the bug rather than surface it.
app.config.errorHandler = (err, _instance, info) => {
    console.error(`dashboard render failed (${info})`, err);
    const message = err instanceof Error ? err.message : String(err);
    // Deferred, and that is the whole trick: Vue patches the failed render's
    // placeholder into `#app` *after* this handler returns — a lone comment
    // node, `<!---->` — so anything written here is overwritten a moment later
    // and the page stays blank. Waiting one turn lets that patch land first.
    setTimeout(() => {
        const root = document.querySelector("#app");
        // Text, not `childElementCount`: the placeholder is a comment, and a
        // comment is not an element, so an element count reads zero on a page
        // that has both failed and been re-rendered.
        if (!root || (root.textContent ?? "").trim() !== "")
            return;
        root.innerHTML =
            `<div class="p-4"><div class="alert alert-danger mb-0">` +
                `<strong>The dashboard failed to render.</strong> ` +
                `<pre class="mt-2 mb-0 small">${message.replace(/[<&]/g, (c) => (c === "<" ? "&lt;" : "&amp;"))}</pre>` +
                `</div></div>`;
    }, 0);
};
app.mount("#app");
